"""API routes package."""

from app.api.routes.analysis import router as analysis_router
from app.api.routes.health import router as health_router
from app.api.routes.statistics import router as statistics_router

__all__ = ["health_router", "analysis_router", "statistics_router"]
